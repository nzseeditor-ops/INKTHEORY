package com.inktheory.editor

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.VideoView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.media3.common.MediaItem
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Transformer
import java.io.File

class MainActivity : ComponentActivity() {
    private var selectedVideo: Uri? = null
    private lateinit var preview: VideoView
    private lateinit var status: TextView
    private lateinit var startSeconds: EditText
    private lateinit var endSeconds: EditText
    private lateinit var exportButton: Button

    private val videoPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedVideo = uri
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            preview.setVideoURI(uri)
            preview.setOnPreparedListener { player ->
                player.isLooping = false
                preview.start()
            }
            status.text = "Video loaded. Set the trim range in seconds, then export."
            exportButton.isEnabled = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 12, 12)
        window.navigationBarColor = Color.rgb(12, 12, 12)
        window.decorView.systemUiVisibility = 0

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(24))
            setBackgroundColor(Color.rgb(12, 12, 12))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        val brand = TextView(this).apply {
            text = "INK THEORY"
            textSize = 28f
            setTextColor(Color.rgb(232, 190, 92))
            letterSpacing = 0.12f
            gravity = Gravity.CENTER
        }
        content.addView(brand, matchWrap())
        val subtitle = TextView(this).apply {
            text = "MOBILE VIDEO STUDIO"
            textSize = 11f
            letterSpacing = 0.18f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(4), 0, dp(22))
        }
        content.addView(subtitle, matchWrap())

        preview = VideoView(this).apply {
            setBackgroundColor(Color.rgb(28, 28, 28))
        }
        content.addView(preview, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(220)
        ).apply { bottomMargin = dp(14) })

        val choose = makeButton("＋  Choose a video")
        choose.setOnClickListener { videoPicker.launch(arrayOf("video/*")) }
        content.addView(choose, matchWrap())

        content.addView(label("TRIM CLIP (SECONDS)"), matchWrap().apply {
            topMargin = dp(22); bottomMargin = dp(8)
        })

        val fields = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startSeconds = EditText(this).apply {
            hint = "Start: 0"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setBackgroundColor(Color.rgb(35, 35, 35))
            setPadding(dp(12), 0, dp(12), 0)
        }
        endSeconds = EditText(this).apply {
            hint = "End: 15"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setBackgroundColor(Color.rgb(35, 35, 35))
            setPadding(dp(12), 0, dp(12), 0)
        }
        fields.addView(startSeconds, LinearLayout.LayoutParams(0, dp(52), 1f).apply {
            rightMargin = dp(8)
        })
        fields.addView(endSeconds, LinearLayout.LayoutParams(0, dp(52), 1f))
        content.addView(fields, matchWrap())

        exportButton = makeButton("Export trimmed video").apply { isEnabled = false }
        exportButton.setOnClickListener { exportTrimmedVideo() }
        content.addView(exportButton, matchWrap().apply { topMargin = dp(14) })

        status = TextView(this).apply {
            text = "Choose a video to begin."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(16), 0, dp(8))
        }
        content.addView(status, matchWrap())

        val note = TextView(this).apply {
            text = "Version 1.0 • Import, preview, trim and export. Exports are saved inside the app's Movies folder."
            textSize = 11f
            setTextColor(Color.GRAY)
            setPadding(0, dp(20), 0, 0)
        }
        content.addView(note, matchWrap())

        page.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(page)
    }

    private fun exportTrimmedVideo() {
        val uri = selectedVideo ?: return
        val start = startSeconds.text.toString().toLongOrNull() ?: 0L
        val end = endSeconds.text.toString().toLongOrNull() ?: 15L
        if (start < 0 || end <= start) {
            Toast.makeText(this, "End time must be greater than start time.", Toast.LENGTH_LONG).show()
            return
        }

        val outputDir = getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES)
        if (outputDir == null) {
            status.text = "Unable to access the app's Movies folder."
            return
        }
        if (!outputDir.exists()) outputDir.mkdirs()
        val outputFile = File(outputDir, "InkTheory_${System.currentTimeMillis()}.mp4")
        exportButton.isEnabled = false
        status.text = "Exporting video… keep the app open."

        try {
            val mediaItem = MediaItem.Builder()
                .setUri(uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(start * 1000)
                        .setEndPositionMs(end * 1000)
                        .build()
                )
                .build()
            val editedItem = EditedMediaItem.Builder(mediaItem).build()
            val transformer = Transformer.Builder(this)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: androidx.media3.transformer.ExportResult) {
                        runOnUiThread {
                            status.text = "Export complete: ${outputFile.name}\nSaved to: ${outputFile.absolutePath}"
                            exportButton.isEnabled = true
                            Toast.makeText(this@MainActivity, "Video exported!", Toast.LENGTH_LONG).show()
                        }
                    }

                    override fun onError(
                        composition: androidx.media3.transformer.Composition,
                        exportResult: androidx.media3.transformer.ExportResult,
                        exportException: androidx.media3.transformer.ExportException
                    ) {
                        runOnUiThread {
                            status.text = "Export failed: ${exportException.message ?: "Unsupported video format"}"
                            exportButton.isEnabled = true
                        }
                    }
                })
                .build()
            transformer.start(editedItem, outputFile.absolutePath)
        } catch (e: Exception) {
            status.text = "Could not start export: ${e.message}"
            exportButton.isEnabled = true
        }
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 12f
        letterSpacing = 0.08f
        setTextColor(Color.rgb(232, 190, 92))
    }

    private fun makeButton(text: String) = Button(this).apply {
        this.text = text
        textSize = 14f
        isAllCaps = false
        setTextColor(Color.BLACK)
        setBackgroundColor(Color.rgb(232, 190, 92))
        minHeight = dp(52)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
