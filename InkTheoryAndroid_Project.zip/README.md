# Ink Theory — Android Video Editor Starter

A native Android starter project using Kotlin and AndroidX Media3 Transformer.

## Current MVP
- Black-and-gold Ink Theory interface
- Pick a video using Android's system file picker
- Preview the selected video
- Enter start/end trim points in seconds
- Export the trimmed clip to the app-specific Movies directory

## Build an APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle to sync and install the Android SDK Platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the location of the generated debug APK, typically:
   `app/build/outputs/apk/debug/app-debug.apk`

## Notes
- This is a starter MVP, not a full CapCut replacement.
- Exported files are currently saved in app-specific storage. Add a MediaStore save flow to make them appear directly in Gallery.
- Test on a real Android device; video codec support varies by device.
- For release, create a signed release APK in Android Studio.
- App package ID: `com.inktheory.editor`
